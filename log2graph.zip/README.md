Project to convert data to plot in html
=======================================

Description:
------------


### Project can do the following
  -- read file or files from path
  -- create graph data from list of numbers
  -- draw graph to html file
 
### Usage:
  -- python __main__.py run <.log file>

Resulted file will be saved for the same directory as log file situated.